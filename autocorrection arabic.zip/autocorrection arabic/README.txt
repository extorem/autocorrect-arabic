1. create database named autocorrection_arabic on mysql database
2. import autocorrection_arabic.sql 
3. in C:\xampp\htdocs\ add the folder "autocorrection_arabic"
4. open your browser 
5. type http://localhost/auto_correction_arabic/index.php
6. write any arabic word and see suggesting
